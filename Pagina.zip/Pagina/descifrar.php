<?php include ("include/header.php"); ?>
	<div id="principal">
		<table width="780" border="0">
			<?php
				$cipher = $_GET["cipher"];
				$usuario = $_GET["usuario"];
				// echo 'java -jar prueba.jar ' . $usuario . ' "' . $cipher . '"';
				// $resultado = exec('java -jar prueba.jar ' . $usuario . ' "' . $cipher . '"'); // Se imprime la respuesta
				$resultado = exec('java -jar rc4.jar ' . $usuario . ' "' . $cipher . '"'); // Se imprime la respuesta
				$split = explode("|", $resultado);
				$clave = $split[0];
				$texto = $split[1];
				echo"<tr>
						<td >
							<h3>
							<label for=\"clave\">Clave</label>
							</h3>
						</td>
					</tr>
					<tr>
						<td >
							<textarea id=\"clave\" rows=\"1\" cols=\"94\">$clave</textarea>
						</td>
					</tr>
					<tr>
						<td >
							<h3>
							<label for=\"descifrado\">Texto descifrado</label>
							</h3>
						</td>
					</tr>
					<tr>
						<td >
							<textarea id=\"descifrado\" rows=\"10\" cols=\"94\">$texto</textarea>
						</td>
					</tr>";
			?>
		</table>
	<div class="espacio"></div>
	</div>
<?php include("include/footer.php"); ?>
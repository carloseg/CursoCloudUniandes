	<div id="footer">
		<br/><!-- espacio en blanco -->
		<p>Cloud App Demo - Juan Sebasti&aacuten Rey y Juan Pablo S&aacuteenz</p>
		<p><a href="/">Inicio</a> | <a id="opener" href="#">C&oacutemo funciona</a></p>
		<div id="dialog" title="Informaci&oacuten">
		<p>Este demo solo puede descifrar texto que cuando descifrado est&aacute compuesto por los 95 caracteres ASCII imprimibles. De igual manera, la clave que se intentar&aacute buscar tiene que estar compuesta por los mismos 95 caracteres ASCII imprimibles.</p>
		</div>
			<script>
				// increase the default animation speed to exaggerate the effect
				$.fx.speeds._default = 1000;
				$(function() {
					$( "#dialog" ).dialog({
						autoOpen: false,
						modal: true,
						show: "blind",
						hide: "explode"
					});

					$( "#opener" ).click(function() {
						$( "#dialog" ).dialog( "open" );
							return false;
					});
				});
				
				$(document).ready(function() {
					$(".boton").button();
				});
			</script>
		</div>
	</div>

	</body>
</html>
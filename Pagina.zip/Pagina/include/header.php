<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" lang="es" xml:lang="es">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
    <title>Cloud App Demo</title>
    <meta name="keywords" content="cloud" />
    <meta name="description" content="AWS Cloud" />
    <!-- jQuery -->
    <script src="/jquery/jquery.js" type="text/javascript"></script>
    <link href="/jquery/css/jquery-ui-1.8.14.custom.css" rel="stylesheet" type="text/css"/>
    <script src="/jquery/jquery-ui-1.8.14.custom.min.js"></script>
    <!-- Nuestro -->
    <link href="/css/estilos-v1.css" rel="stylesheet" type="text/css" />
</head>

  <body>
	
    <div id="wrapper">
      <div id="header"></div>
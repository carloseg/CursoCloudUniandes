<?php include ("include/header.php"); ?>
	<div id="principal">
		<form id="form_aws" action="/descifrar.php" method="get">
			<table width="780" border="0">
				<tr>
					<td >
						<h3>
							<label for="usuario">Llave</label>
						</h3>
					</td>
				</tr>
				<tr>
					<td >
						<input id="usuario" name="usuario" type="text"/>
					</td>
				</tr>
				<tr>
					<td >
						<h3>
						<label for="cipher">Texto cifrado</label>
						</h3>
					</td>
				</tr>
				<tr>
					<td >
						<textarea id="cipher" name="cipher" rows="10" cols="94"></textarea>
					</td>
				</tr>
				<tr>
					<td >
						<input class="boton" value="Descifrar" type="submit"/>     
					</td>
				</tr>
			</table>
		<div class="espacio"></div>
		</form>
	</div>
<?php include("include/footer.php"); ?>